﻿using ConsoleBoasPraticarEntityframework.Data;
using ConsoleBoasPraticarEntityframework.Data.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleBoasPraticarEntityframework
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
             //CriaBase();
            // ConsultasAsNoTracking();
            //FormasConsulta();
            // ConsultasSomenteNecessario();
            //FiltrosMemoria();
            //ConsultasSimplificada();
            //ConsultasNOLOCK();
        }


        /// <summary>
        /// Utilizando AsNoTracking
        /// </summary>
        public static void ConsultasAsNoTracking()
        {
            using (var dataBase = new Contexto())
            {
                var query = from Item in dataBase.ItemPedido
                            where Item.IdPedido > 0
                            select Item;

                var resultado = query.AsNoTracking().ToList();

                foreach (var item in resultado)
                {
                    Console.WriteLine(string.Concat("Item - ", item.NomeItem));
                }

                Console.Read();
            };
        }


        /// <summary>
        ///  Formas de consultas
        /// </summary>
        public static void FormasConsulta()
        {

            //ERRADA
            using (var dataBase = new Contexto())
            {
                var query = from Pred in dataBase.Pedido.ToList()
                            join Item in dataBase.ItemPedido.ToList() on Pred.Id equals Item.IdPedido

                            where Pred.Id < 3
                            select new { Pedido = Pred.NomePedido, NomeItem = Item.NomeItem };

                var resultado = query.ToList();

                foreach (var item in resultado)
                {
                    Console.WriteLine(string.Concat("Pedido : ", item.Pedido,  "  -  Item : ", item.NomeItem));
                }

                Console.Read();

            }

            // CORRETA
            using (var dataBase = new Contexto())
            {
                var query = from Pred in dataBase.Pedido
                            join Item in dataBase.ItemPedido on Pred.Id equals Item.IdPedido

                            where Pred.Id < 3
                            select new { Pedido = Pred.NomePedido, NomeItem = Item.NomeItem };

                var resultado = query.ToList();

                foreach (var item in resultado)
                {
                    Console.WriteLine(string.Concat("Pedido : ", item.Pedido,  "  -  Item : ", item.NomeItem));
                }

                Console.Read();



            }
        }


        /// <summary>
        ///  Consultas somente o necessario
        /// </summary>
        public static void ConsultasSomenteNecessario()
        {

            using (var dataBase = new Contexto())
            {
                var query = from Pred in dataBase.Pedido
                            join Item in dataBase.ItemPedido on Pred.Id equals Item.IdPedido

                            where Pred.Id < 3
                            select new { Pedido = Pred.NomePedido, NomeItem = Item.NomeItem };

                var resultado = query.ToList();

                foreach (var item in resultado)
                {
                    Console.WriteLine(string.Concat("Pedido : ", item.Pedido,  "  -  Item : ", item.NomeItem));
                }

                Console.Read();

            }
        }


        /// <summary>
        ///  Filtros em memoria
        /// </summary>
        public static void FiltrosMemoria()
        {
            //ERRADO 
            using (var dataBase = new Contexto())
            {
                var query = (from Pred in dataBase.Pedido
                             join Item in dataBase.ItemPedido on Pred.Id equals Item.IdPedido
                             select Pred).ToList();

                var resultado = query.Where(P => P.NomePedido.Contains('P') && P.NomePedido.StartsWith('P'));

                foreach (var item in resultado)
                {
                    Console.WriteLine(string.Concat("Pedido : ", item.Id, "  -  Nome : ", item.NomePedido));
                }

                Console.Read();

            }



            // CORRETO
            using (var dataBase = new Contexto())
            {
                var query = from Pred in dataBase.Pedido
                            join Item in dataBase.ItemPedido on Pred.Id equals Item.IdPedido

                            where Pred.NomePedido.Contains('P') && Pred.NomePedido.StartsWith('P')
                            select Pred;

                var resultado = query.ToList();

                foreach (var item in resultado)
                {
                    Console.WriteLine(string.Concat("Pedido : ", item.Id, "  -  Nome : ", item.NomePedido));
                }

                Console.Read();
            }


            /// CORRETO 


        }

        /// <summary>
        ///  Consultas Simplificadas
        /// </summary>
        public static void ConsultasSimplificada()
        {

            using (var dataBase = new Contexto())
            {
                var query = from Pred in dataBase.Pedido
                            join Item in dataBase.ItemPedido on Pred.Id equals Item.IdPedido

                            where Pred.Id < 3

                            select new Pedido
                            {
                                NomePedido = Pred.NomePedido
                            };

                var resultado = query.ToList();

                foreach (var item in resultado)
                {
                    Console.WriteLine(string.Concat("Pedido : ", item.NomePedido));
                }

                Console.Read();

            }
        }


        /// <summary>
        ///  Consultas SimpliNOLOCKficadas
        /// </summary>
        public static void ConsultasNOLOCK()
        {

            using (var dataBase = new Contexto())
            {

                using (var tran = dataBase.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
                {

                    var query = from Pred in dataBase.Pedido
                                join Item in dataBase.ItemPedido on Pred.Id equals Item.IdPedido

                                where Pred.Id < 3
                                select new Pedido
                                {
                                    NomePedido = Pred.NomePedido
                                };

                    var resultado = query.ToList();

                    foreach (var item in resultado)
                    {
                        Console.WriteLine(string.Concat("Pedido : ", item.NomePedido));
                    }

                    Console.Read();

                    tran.Commit();
                }                          

            }
        }




        /// <summary>
        /// 
        /// </summary>
        public static void CriaBase()
        {
            using (var dataBase = new Contexto())
            {
                for (int i = 1; i <= 5; i++)
                {
                    var _Pedido = dataBase.Pedido.Add(new Pedido
                    {
                        NomePedido = string.Concat("Pedido Numero: ", i.ToString())
                    });

                    dataBase.SaveChanges();
                    var ListaItensPedido = new List<ItemPedido>();

                    for (int y = 1; y < 100; y++)
                    {
                        ListaItensPedido.Add(new ItemPedido
                        {
                            IdPedido = _Pedido.Entity.Id,
                            NomeItem = string.Concat("Nome item Numero: ", y.ToString())
                        });
                    }

                    dataBase.ItemPedido.AddRange(ListaItensPedido);

                    dataBase.SaveChanges();
                }

            }
        }

    }
}
