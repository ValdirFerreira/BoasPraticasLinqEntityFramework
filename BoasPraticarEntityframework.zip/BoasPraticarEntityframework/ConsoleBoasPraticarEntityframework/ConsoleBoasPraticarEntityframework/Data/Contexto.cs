﻿using ConsoleBoasPraticarEntityframework.Data.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleBoasPraticarEntityframework.Data
{
    public class Contexto : DbContext
    {

        public Contexto()
        {
            // Verifica se não existe base , criaa a base e a tabela           
            Database.EnsureCreated();
        }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Se não estiver configurado no projeto IU pega deginição de chame do json configurado

            string conexao = "Data Source=DESKTOP-2843A39\\SQLEXPRESS;Initial Catalog=BoasPraticas;Integrated Security=False;User ID=sa;Password=1234;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False";
            if (!optionsBuilder.IsConfigured)
                optionsBuilder.UseSqlServer(conexao);

            base.OnConfiguring(optionsBuilder);

        }

        public DbSet<Pedido> Pedido { get; set; }
        public DbSet<ItemPedido> ItemPedido { get; set; }
    }
}
